import KobaAnimationColors from "@/components/kobalib/colors/koba-animation-colors";
import { ThemedText } from "@/components/themed-text";
import { useLedStripsStore } from "@/hooks/use-ledstrips";
import { View } from "react-native";
import AnimationWrapper from "../animation-settings-wrapper";

export default function SolidAnimationSettings() {
  const { update, selected } = useLedStripsStore();

  return (
    <AnimationWrapper>
      {(animation) => {
        const animIndex = selected.animations.findIndex(
          (anim) => anim.id === animation.id, // animation.id
        );

        if (animIndex === -1) {
          return <ThemedText>Animation not found on this strip.</ThemedText>;
        }

        const currentAnim = selected.animations[animIndex];
        
        const handleNewAnimationData = (data: any) => {
          const newAnimations = [...selected.animations];
          const anim = newAnimations[animIndex];

          newAnimations[animIndex] = {
            ...anim,
            ...data
          };

          update({ id: selected.id, animations: newAnimations });
        };

        return (
          <View className="flex">

            {/* // Az a baj, hogy ha leupdateli akkor a belső componentnekben a "régi" initialAnimation marad. */}
            <KobaAnimationColors initialAnimation={currentAnim} onChange={handleNewAnimationData} />
          </View>
        );
      }}
    </AnimationWrapper>
  );
}
