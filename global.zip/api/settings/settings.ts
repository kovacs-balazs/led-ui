import { BASE_URL } from "../api";

export async function getSettings() {
  const response = await fetch(`${BASE_URL}/api/settings`);

  if (!response.ok) {
    throw new Error("Failed to fetch led strips");
  }

  return response.json();
}

export async function updateSettings(payload: unknown) {
  const response = await fetch(`${BASE_URL}/api/settings/update`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  console.log(JSON.stringify(payload));

  if (!response.ok) {
    throw new Error("Failed to update led strips");
  }

  return response.json();
}
